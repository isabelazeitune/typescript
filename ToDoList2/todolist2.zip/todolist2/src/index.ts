import "./style.css";
import "material-icons/iconfont/material-icons.css";

console.log("Uêpah!");